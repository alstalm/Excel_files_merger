from functions import excelCombiner

# зададим переменные
directory = 'C:/Users/alsta/PycharmProjects/Jira_attachmets_downloader/downloads'
sheet_name = 'Внесение изменений'
notNANcolumnsList = ['ИНН участника']

# выполним объединение
df, log_df = excelCombiner(directory=directory, sheet_name=sheet_name, notNANcolumnsList=notNANcolumnsList)

# выведем результаты
print('\nlog_df =\n  {} '.format(log_df))
print('\ndf = \n {}'.format(df.to_string()))

# сохраним результаты
df.to_excel('output/merged_result.xlsx', index=False)
log_df.to_excel('output/log.xlsx', index=False)
